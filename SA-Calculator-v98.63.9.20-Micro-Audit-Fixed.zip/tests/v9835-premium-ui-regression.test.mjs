import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");
const css=read("assets/css/app.css");
const html=read("index.html");
const pkg=JSON.parse(read("package.json"));
test("v98.35 touch-focus fix hides the skip-link ghost while keyboard focus remains visible",()=>{
 assert.match(css,/\.skip-to-workspace:focus \{[^}]*opacity:0 !important/);
 assert.match(css,/\.skip-to-workspace:focus-visible \{[^}]*opacity:1 !important/);
 assert.match(css,/focus:not\(:focus-visible\)/);
 assert.match(html,/href="#screen-viewport"/);
});
test("v98.46 Tools menu contains 16 dedicated tools plus Scientific Calculator, without Home or Settings duplicates",()=>{
 const cards=[...html.matchAll(/data-tool-screen="([^"]+)"/g)].map(m=>m[1]);
 const expected=['currencies','units','discount','salestax','loan','savings','tip','unitprice','percent','gradeavg','hex','scientific','bodymetrics','date','fuelcost','fuelefficiency','worldtime'];
 assert.deepEqual(cards,expected); assert.equal(new Set(cards).size,17);
 assert.match(html,/id="tools-screen-search"/); assert.match(html,/id="screen-tools"/);
 assert.match(html,/id="tools-category-list"/);
 assert.doesNotMatch(html,/data-tool-screen="(?:calc|settings)"/);
});
test("v98.44 dedicated Tools screen has responsive premium card styling",()=>{
 const premium=read("assets/css/app.css")+read("assets/css/app.css");
 assert.match(premium,/\.premium-tools-grid/); assert.match(premium,/grid-template-columns: repeat\(2, minmax\(0, 1fr\)\)/);
 assert.match(premium,/max-width: 360px/); assert.match(premium,/prefers-reduced-motion/);
});

test("v98.35 release identity is synchronized",()=>{assert.equal(pkg.version,"1.98.65-v98.63.9.17");});
