import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('v98.63.6 dock does not double-reserve Android bottom safe area', () => {
  const css = read('assets/css/app.css');
  const dock = css.match(/#app-container > #bottom-navigation\.bottom-navigation\s*\{([^}]*)\}/s)?.[1] || '';
  assert.match(dock, /flex:0 0 var\(--sa-dock-height\)!important/);
  assert.match(dock, /height:var\(--sa-dock-height\)!important/);
  assert.doesNotMatch(dock, /safe-area-inset-bottom/);
  assert.match(css, /#bottom-navigation \.bottom-nav-item\s*\{[^}]*height:100%/s);
});

test('v98.63.6 currency picker renders a vertical list and does not reserve a hidden keypad', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /\.sumaire-picker-options\s*\{[^}]*flex-direction:column/s);
  assert.match(css, /\.sumaire-picker-option\s*\{[^}]*display:grid/s);
  assert.match(css, /#screen-currencies > \.currency-dock-keypad[^}]*display:none/s);
  const js = read('assets/js/app.js');
  assert.match(js, /closeButton \|\| panel\)\.focus\(\{ preventScroll: true \}\)/);
  assert.doesNotMatch(js, /searchInput\.focus\(/);
});

test('v98.63.6 final CSS layer is included in Android web build', () => {
  const build = read('scripts/prepare-android-web.mjs');
  assert.match(build,/assets\/css\/app\.css/);
  assert.match(read('assets/css/app.css'), /v98\.63\.6 — final correction/);
  const workflow = read('.github/workflows/main.yml');
  assert.match(workflow,/assets\/css\/app\.css/);
  assert.match(workflow, /sa-calculator-v98-63-10-clean-runtime-v9863917/);
});
