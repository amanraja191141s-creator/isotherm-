const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('v98.32 tool screens hide the duplicate global app header and use one injected toolbar', () => {
  const css = read('assets/css/app.css');
  const js = read('assets/js/app.js');
  assert.match(css, /body\.tool-screen-active #app-container > header\.app-header \{ display:none !important/);
  assert.match(css, /header\.app-header::before, header\.app-header::after \{ content:none !important/);
  assert.match(js, /document\.body\.classList\.toggle\('tool-screen-active', screenId !== 'calc' && screenId !== 'tools'\)/);
  assert.match(js, /className = 'reference-screen-toolbar'/);
});

test('drawer has no duplicate pseudo icon column, Settings tile or static Calculator row', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css');
  const js = read('assets/js/app.js');
  assert.doesNotMatch(html, /id="menu-settings"|id="btn-header-settings"|class="drawer-item active" data-screen="calc"/);
  assert.match(css, /#sidebar-drawer \.drawer-item::before,#sidebar-drawer \.drawer-item::after \{ content:none !important/);
  assert.match(html, /id="menu-help"/);
  assert.match(html, /id="screen-scientific"/);
  assert.doesNotMatch(html, /id="btn-sci-open"/);
  assert.match(html, /id="btn-history-open"/);
  assert.match(js, /const drawerFavorites = safeFavorites\.filter\(id => id !== 'calc'\)/);
});

test('currency picker has a searchable currency-only filter while other pickers remain compact', () => {
  const js = read('assets/js/app.js');
  const css = read('assets/css/app.css');
  assert.match(js, /sumaire-picker-search-wrap/);
  assert.match(js, /const searchableCurrency = \/\^cur-\(from\|to\)\$\//);
  assert.match(js, /No matching currencies/);
  assert.match(css, /\.sumaire-picker-search-wrap/);
});

test('currency/unit picker exposes only one explicit close action', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /sumaire-picker-close/);
  assert.doesNotMatch(js, /sumaire-picker-cancel/);
  assert.doesNotMatch(js, /sumaire-picker-footer/);
});

test('Body Metrics has no empty pill and uses a compact informational note', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css');
  assert.match(html, /class="body-info-note"/);
  assert.match(css, /#screen-bodymetrics #bmi-status\[hidden\],#screen-bodymetrics #bmi-status:empty \{ display:none !important/);
  assert.match(css, /#screen-bodymetrics #body-metric-result\[data-state="empty"\].*background:#0b1d34/s);
});

test('Fuel Cost displays one neutral prompt until a valid calculation is produced', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const css = read('assets/css/app.css');
  assert.match(html, /id="fc-empty-note"/);
  assert.match(html, /id="fuel-cost-result"[^>]*hidden/);
  assert.match(js, /result\.hidden = state !== 'success'/);
  assert.match(js, /Complete all three fields to calculate/);
  assert.match(css, /#screen-fuelcost #fuel-cost-result\[hidden\] \{ display:none !important/);
});

test('Unit Price removes duplicate trophy/check decoration and initial false focus', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css');
  const unitPrice = html.slice(html.indexOf('id="screen-unitprice"'), html.indexOf('id="screen-worldtime"'));
  assert.doesNotMatch(unitPrice, /reference-result-icon|reference-best-check/);
  assert.doesNotMatch(html, /id="up-p-a" data-target="up-p-a"[^>]*class="input-val-box active"/);
  assert.match(css, /#screen-unitprice \.reference-best-check, #screen-unitprice \.reference-result-icon \{ display:none !important/);
});

test('World Time removes the redundant search glyph and uses a compact hero', () => {
  const html = read('index.html');
  const css = read('assets/css/app.css');
  assert.doesNotMatch(html, /reference-world-search"><span>⌕/);
  assert.match(css, /#screen-worldtime \.reference-world-globe \{ width:48px/);
  assert.match(css, /#screen-worldtime \.reference-world-hero \{ min-height:82px/);
});

test('Scientific modal avoids a duplicate percent key while the main keypad retains percent', () => {
  const html = read('index.html');
  assert.match(html, /id="screen-scientific"/);
  assert.doesNotMatch(html, /id="sci-modal-overlay"/);
  assert.match(html, /class="key-btn utility-key" data-calc="%"|data-calc="%"/);
});


test('All non-calculator tools remain in the dedicated Tools grid after the old drawer list is removed', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const allSection = html.slice(html.indexOf('id="premium-tools-grid"'), html.indexOf('id="tools-empty-state"'));
  for (const id of ['currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime']) {
    assert.match(allSection, new RegExp('data-tool-screen="' + id + '"'));
  }
  assert.match(html, /id="tools-screen-search"/);
  assert.match(js, /const filterToolsScreen = \(\) =>/);
  assert.doesNotMatch(html.slice(html.indexOf('id="sidebar-drawer"'), html.indexOf('</aside>')), /Quick access|drawer-category/);
});

test('Quick Guide remains manually opened from Help, not auto-opened during startup', () => {
  const js = read('assets/js/app.js');
  assert.match(js, /function showHelpModal\(\) \{ openSupportModal\('help-modal'\); \}/);
  assert.equal((js.match(/showHelpModal\(\);/g) || []).length, 1);
  assert.ok(js.indexOf("document.getElementById('menu-help')?.addEventListener('click'") < js.indexOf('showHelpModal();'));
});

test('v98.32 version, cache and Android workflow identities are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  assert.equal(pkg.version, '1.98.65-v98.63.9.17');
  assert.equal(manifest.version, pkg.version);
  assert.match(read('index.html'), /sa-build-version" content="1\.98\.65-v98\.63\.9\.17/);
  assert.match(read('assets/js/app.js'), /APP_VERSION = '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(read('service-worker.js'), /sa-calculator-v98-63-10-clean-runtime-v9863917/);
  const a = read('.github/workflows/main.yml');
  assert.equal(read('.github/workflows/main.yml'), a);
  assert.equal(read('.github/workflows/main.yml'), a);
  assert.equal(read('.github/workflows/main.yml'), a);
  assert.match(a, /SA_EXPECTED_VERSION: '1\.98\.65-v98\.63\.9\.17'/);
  assert.match(a, /versionCode='1098065'/);
});
