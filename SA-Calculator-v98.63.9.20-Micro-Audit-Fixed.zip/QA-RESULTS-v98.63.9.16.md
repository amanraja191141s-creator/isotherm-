# SA Calculator v98.63.9.16 — Converter Picker QA

## Source changes
- Removed selected-only filtering from the currency and unit option picker.
- Full option lists render on first open; search is an optional live filter.
- Currency picker rows render the existing country/region flag glyph with localized name, ISO code and region.
- Currency screen flag spans are explicitly visible.
- Unit rows now use a two-column grid (label + selected indicator); currency rows use three columns (flag + label + selected indicator).
- Picker search/list scrolling, selection state, close behavior, and existing conversion data paths are preserved.

## Automated verification
- Regression suite: run with `npm test`.
- Web bundle: run with `npm run build:web`.
- YAML syntax: validate `.github/workflows/main.yml`.
- ZIP integrity: validate with `unzip -t`.

## Device verification limitation
The uploaded recording was inspected at representative points across its 93-second duration. It shows the currency converter screen with a blank/placeholder-looking flag glyph, and the unit picker with the option label constrained into an excessively narrow first grid column. The source corrections address those observed causes. Actual Android WebView installation and visual verification still require a fresh APK on the target device.
