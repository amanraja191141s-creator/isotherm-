# QA results — v98.63.9.11

- Automated regression suite: **381 passed, 0 failed**.
- JavaScript syntax: passed (`node --check assets/js/app.js`).
- Android web bundle: passed (`npm run build:web`, all 13 required assets verified).
- Browser/Android asset parity: covered by automated tests.
- Calculator display sizing and five-row keypad layout: source-level regression tests passed.
- Currency/unit picker selected-only initial state, two-character search threshold, and eight-result cap: source-level regression tests passed.
- ZIP integrity and workflow YAML syntax: verified after packaging.

Physical Android rendering, device-specific font metrics, live currency-provider availability, APK installation, and runtime performance require a device/build runner and are not certified by source tests alone.
