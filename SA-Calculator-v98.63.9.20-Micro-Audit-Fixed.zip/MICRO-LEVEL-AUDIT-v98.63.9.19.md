# Micro-level audit — v98.63.9.19

## Source basis
The exact v98.63.9.18 ZIP and the user's 5.36-second 720×1560 recording were inspected. The recording shows a keypad-level split: the normal numeric keypad stays on the left while a compact scientific function grid enters from the right. It does not show a full-screen scientific calculator with its own display and numeric keypad.

## Confirmed v98.63.9.18 mismatches
1. Drawer occupied 88vw and the full calculator height, obscuring almost the entire normal calculator instead of forming a side-by-side keypad split.
2. The scientific panel retained a second display/editor, separate numeric keypad, memory controls and history controls, unlike the reference interaction.
3. Scientific function buttons wrote to the hidden `#sci-expression` rather than the main calculator expression, so users did not get one shared expression/preview/result flow.
4. DEG/RAD was stored only in the isolated scientific state; the main calculator evaluator continued to use its default angle mode.
5. Scientific Calculator still existed in the `ALL_CALC_ITEMS` favorites/tool source array even though the card had been removed from the HTML.

## Corrections in v98.63.9.19
- The main keypad contracts to 46% width (44% on <=360px phones); the scientific panel occupies the right 54% (56% on <=360px phones), at the keypad's lower 64% workspace height.
- Only the scientific function grid and compact SHIFT/DEG-RAD/close controls remain visible in the side panel.
- Function taps insert into the standard calculator's real expression at the current selection/caret. Selected expressions are wrapped by function tokens when appropriate.
- Main preview, result, history, parser, cursor and equals path remain the single source of truth.
- Shared angle mode is passed to all standard live-preview, equals and repeat-evaluation calls.
- Reverse swipe, close button, Escape, pointer cancellation, `aria-hidden` and `inert` handling remain.
- Obsolete scientific destination removed from favorites/tool source data.

## Validation limits
Automated tests and static source checks do not certify Android touch feel, frame pacing, or the exact physical-device rendering. Fresh APK installation and on-device gesture verification remain necessary.
