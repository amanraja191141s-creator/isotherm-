# Changelog — v98.63.9.19

- Reworked the scientific interaction to match the supplied recording: a right-edge swipe reveals a function-only panel beside the normal keypad, at keypad height.
- The standard keypad remains visible on the left and contracts to 46% width while the scientific function panel slides into the right 54%; small phones use a 44/56 split.
- Removed the duplicate scientific display, duplicate numeric keypad, memory row, history panel and extra-functions drawer from the visible side panel. The main calculator display remains the single expression/preview/result surface.
- Scientific function buttons now insert into the main calculator expression at its real caret/selection, preserving the normal preview and equals workflow.
- DEG/RAD is shared with the main evaluator, so trig and inverse-trig functions use the selected angle mode.
- Kept SHIFT alternate function labels, close button, reverse swipe, Escape and accessible inert/aria-hidden state.
- Removed the obsolete Scientific Calculator item from the Tools/favorites catalog.
- Increased edge gesture zone and adjusted touch behavior for Android WebView.
- Updated release identity, PWA cache namespace, Android build workflow and regression tests.
