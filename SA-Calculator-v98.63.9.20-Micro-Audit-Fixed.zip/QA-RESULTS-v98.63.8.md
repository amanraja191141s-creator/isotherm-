# QA results — SA Calculator v98.63.8

## Source and build checks
- Node regression suite: **375 passed, 0 failed**.
- JavaScript syntax: passed for source and generated Android web bundle.
- Android web bundle: regenerated successfully; 37 required assets verified and 25 CSS layers consolidated.
- Android workflow YAML: parsed successfully.
- Production bundle contains the v98.63.8 final CSS layer.
- Service-worker cache namespace migrated to `sa-calculator-v98-63-exact-ui-fix-v98638`.
- ZIP archive integrity: checked after packaging.

## Changes covered
- Picker selection uses a selected-option resolver with a fallback to the current value / first enabled option. Currency and unit picker lists show only the selected item before search; search displays matches.
- Native selects are hidden from the touch/paint layer once the accessible custom picker is installed.
- High-specificity final CSS overrides previous keypad dimensions and reduces button size while keeping minimum touch dimensions.
- Home display is full width on phones and capped at 700 CSS px on larger screens.

## Not claimed
No physical Android device/APK installation, Vivo WebView screenshot, or real-device performance benchmark was run in this environment. Automated tests do not prove zero bugs or lag-free performance on every device.
